var i = 1;

var testNum = {
  "1": {
    "title": "문제1번",
    "description": "모임이나 회의 시간에 당신은?",
    "type": "EI",
    "A": "거침 없이 내 의견을 모두 표현한다",
    "B": "내 의견을 표출하는 것을 망설이는 경우가 많다"
  },
  "2": {
    "title": "문제2번",
    "description": "여러 사람 앞에서 발표를 해야 한다면?",
    "type": "EI",
    "A": "내 능력을 발휘해서 인정 받을 수 있는 좋은 기회!",
    "B": "아 ~ 어떡하지... 제발 발표가 무산되길..."
  },
  "3": {
    "title": "문제3번",
    "description": "업무 중에 갑자기 컴퓨터가 멈춘다면?",
    "type": "EI",
    "A": "먼저 동료에게 해결 방법을 물어본다",
    "B": "조용히 구글링해서 원인을 찾고, 가급적 스스로 해결한다."
  },
  "4": {
    "title": "문제4번",
    "description": "동료가 잘 모르는 것을 질문하면?",
    "type": "SN",
    "A": "A부터 Z까지 관련된 것들을 가능한 상세하게 설명한다",
    "B": "질문에 대해 꼭 필요한 핵심 내용만 알려준다"
  },
  "5": {
    "title": "문제5번",
    "description": "오늘 저녁 장소를 정해야 한다면?",
    "type": "SN",
    "A": "데이터를 모아서 비용, 거리, 시간 등을 꼼곰하게 비교해본다",
    "B": "이름, 사진 등 느낌이 좋은 곳으로 정한다"
  },
  "6": {
    "title": "문제6번",
    "description": "월 천만원의 수입이 생기는 부업을 소개 받는다면?",
    "type": "SN",
    "A": "해당 부업의 실적과 인기도, 리뷰 등을 종합 검토한다",
    "B": "미래 수익이 생길 가능성을 직감으로 판단한다"
  },
  "7": {
    "title": "문제7번",
    "description": "친한 친구가 교통사고가 났다고 연락한다면?",
    "type": "TF",
    "A": "보험회사 접수했어? 병원 입원했어?",
    "B": "몸은 괜찮아? 안 다쳤어? 다행이다 ~"
  },
  "8": {
    "title": "문제8번",
    "description": "친구가 중요한 시험에 떨어졌다면?",
    "type": "TF",
    "A": "왜 떨어졌어? 몇 점이나 받은거야?",
    "B": "괜찮아... 다음에 잘 보면 돼!"
  },
  "9": {
    "title": "문제9번",
    "description": "친구가 오늘 한턱 쏜다고 말한다면?",
    "type": "TF",
    "A": "뭐 먹을까? 어디갈까?",
    "B": "와우 ~~ 기분 좋은 일 있나보네! 축하해!"
  },
  "10": {
    "title": "문제10번",
    "description": "해외로 온 가족이 함께 여행을 간다면?",
    "type": "JP",
    "A": "하루하루 볼 것, 먹을 것, 즐길 것을 미리 정해 놓는다",
    "B": "현장 상황에 맞게 여행 코스를 자유롭게 즐기면 돼!"
  },
  "11": {
    "title": "문제11번",
    "description": "친구와 약속 시간에 5분 늦을 것 같다면?",
    "type": "JP",
    "A": "5분 전에 전화해서 늦을 것 같다고 이야기한다",
    "B": "그 정도는 기다려 주겠지 ... 그냥 자연스럽게 넘어간다"
  },
  "12": {
    "title": "문제12번",
    "description": "이메일함에 이메일이 쌓이면?",
    "type": "JP",
    "A": "지저분한 건 못 참아! 가능한 빨리 읽고 처리한다",
    "B": "일단 쌓아 놓고 한꺼번에 몰아서 처리한다"
  }
};

var result = {
  "INTJ": {
    "mbti": "용의주도한 전략가",
    "explain": "INTJ는 혼자 또는 소규모 그룹으로 작업하는 것을 선호합니다. 간섭이 최소화되는 환경에 있어야 합니다. 그들은 자기 방식대로 하기를 좋아하는 창조적인 완벽주의자들입니다.\n\nINTJ는 다음과 같은 직업 유형에 탁월합니다",
    "explain2": "엔지니어 / 소프트웨어 엔지니어 / 변호사 / 프로젝트 매니저 / 이코노미스트",
    "result_imgname": "img/INTJ.jpeg"
  },
  "INTP": {
    "mbti": "논리적인 사색가",
    "explain": "IINTP는 혼자 일하는 것을 선호합니다. 그들은 지적 자극이 필요하고, 자기 주도적이고 훌륭한 문제 해결사입니다.\n\nINTP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "엔지니어 / 데이터 분석가 / 건축가 / 대학교수 / 이코노미스트",
    "result_imgname": "img/INTP.jpeg"
  },
  "ENTJ": {
    "mbti": "대담한 통솔자",
    "explain": "ENTJ는 다른 사람들에게 둘러싸여 작업장에 있는 것을 선호합니다. 그들은 분명하고 간결할 수 있고, 리더십과 책임감을 즐깁니다.\n\nENTJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "비즈니스 관리자 / 리더십 역할 / 대학교수",
    "result_imgname": "img/ENTJ.jpeg"
  },
  "ENTP": {
    "mbti": "뜨거운 논쟁을 즐기는 변론가",
    "explain": "ENTP는 훌륭한 전달자입니다. ENTP는 그들의 관심을 끄는 문제들을 이해하고 해결하기 위해 충분히 노력하기를 기대하고 필요로 합니다.\n\nENTP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "엔지니어 / 변호사 / 판매 담당자 / 사진작가",
    "result_imgname": "img/ENTP.jpeg"
  },
  "INFJ": {
    "mbti": "선의의 옹호자",
    "explain": "INFJ는 창의성과 통찰력을 표현합니다. 그들은 그들이 사람들을 돕고 연결한다는 것을 알기 위해 그들의 일에 의미를 찾습니다.\n\nINFJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "작가 / HR 매니저 / 고객 관계 관리자 / 의사 / 사회복지사",
    "result_imgname": "img/INFJ.jpeg"
  },
  "INFP": {
    "mbti": "열정적인 중재자",
    "explain": "INFP는 대면 업무에서 일하는 것을 선호합니다. 그들은 스트레스가 많은 환경에서는 잘하지 못합니다.\n\nINFP는 다음 직업 유형에 탁월합니다.",
    "explain2": "인재 개발 강사 / 소셜워크 / 그래픽 디자이너 / 심리학자 / 치료사 / 작성자 / 편집자",
    "result_imgname": "img/INFP.jpeg"
  },
  "ENFJ": {
    "mbti": "정의로운 사회운동가",
    "explain": "ENFJ는 지적이고 따뜻하며 창의적이고 사교적입니다. 그들은 다른 사람들을 돕는 것을 즐기고, 다른 사람들에게 관심을 갖고, 다른 사람들이 원하는 것을 선택하는 경향이 있습니다.\n\nENFJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "판매 담당자 / 인사 관리자 / 홍보 전문가",
    "result_imgname": "img/ENFJ.jpeg"
  },
  "ENFP": {
    "mbti": "재기발랄한 활동가",
    "explain": "ENFP는 새로운 아이디어를 탐색하고 관심사를 공유하는 다른 사람들과 일하는 것을 즐기는 변화를 추구합니다. 그들은 좋은 사람 기술을 가지고 있고 그들이 한계를 넘을 수 있는 직업을 가질 필요가 있습니다.\n\nENFP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "선생님 / 이벤트 기획자 / 엔지니어 / 컨설턴트 / 기자",
    "result_imgname": "img/ENFP.jpeg"
  },
  "ISTJ": {
    "mbti": "청렴결백한 논리주의자",
    "explain": "ISTJ들은 열심히 일하는 사람들입니다. 그들은 정의된 규칙을 가지고 구조화된 환경에서 일하는 것을 선호합니다. 권위를 존중하고 개인적이고 전문적인 발전에 초점을 맞춥니다.\n\nISTJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "변호사 / 경찰관 / 감사자 / 비즈니스 관리자 / 공무원",
    "result_imgname": "img/ISTJ.jpeg"
  },
  "ISFJ": {
    "mbti": "용감한 수호자",
    "explain": "ISFJ는 훌륭한 서비스를 믿는 헌신적이고 열심히 일하는 사람들입니다. 그들은 일상적인 도전에 대한 해결책을 찾는 것을 즐깁니다.\n\nISFJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "관리자 / 간호사 / 선생님 / 고객 서비스 담당자 / 인테리어 디자이너",
    "result_imgname": "img/ISFJ.jpeg"
  },
  "ESTJ": {
    "mbti": "엄격한 관리자",
    "explain": "ESTJ는 명확하고 일관된 경향을 보입니다. 질서를 세우고 규칙을 준수하며 높은 기준에 따라 작업이 완료되도록 합니다.\n\nESTJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "판매 담당자 / 감사자 / 프로젝트 매니저 / 변호사 / 관리자",
    "result_imgname": "img/ESTJ.jpeg"
  },
  "ESFJ": {
    "mbti": "사교적인 외교관",
    "explain": "ESFJ는 잘 조직되어 있으며 업무 현장에 질서와 구조를 제공하는 것을 좋아합니다. 계층 구조 및 태스크가 명확하고 예측 가능한 환경에서 가장 잘 작동하는 경우가 많습니다.\n\nESFJ는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "회계사 / 선생님 / 소셜 워크",
    "result_imgname": "img/ESFJ.jpeg"
  },
  "ISTP": {
    "mbti": "만능 재주꾼",
    "explain": "ISTP는 종종 예측 불가능성과 흥분감을 필요로 합니다. 그들은 작은 공간과 해결해야 할 실제적인 문제를 가지고 일하는 것을 즐깁니다.\n\nISTP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "소방관 / 경찰관 / 엔지니어 / 그래픽 디자이너 / 이코노미스트",
    "result_imgname": "img/ISTP.jpeg"
  },
  "ISFP": {
    "mbti": "호기심 많은 예술가",
    "explain": "ISFP는 자신의 방식대로 할 수 있는 자리를 찾습니다. 그들은 타고난 자질을 표현하고 창조적인 자유를 추구할 수 있는 능력을 원합니다.\n\nISFP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "예술가 / 디자이너 /사진작가 / 매장주 / 패션 디자이너",
    "result_imgname": "img/ISFP.jpeg"
  },
  "ESTP": {
    "mbti": "모험을 즐기는 사업가",
    "explain": "ESTP는 그들의 노력에 대한 즉각적인 결과를 갈망합니다. 그들은 호기심이 많고, 행동을 좋아하는 에너지 넘치는 사람들입니다.\n\nESTP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "은행원 / 경찰관 / 선수 / 군인 / 코치",
    "result_imgname": "img/ESTP.jpeg"
  },
  "ESFP": {
    "mbti": "자유로운 영혼의 연예인",
    "explain": "ESFP는 작업장을 친근하고 즐거운 장소로 만드는 것을 좋아합니다. 그들은 사회적이고 편안한 태도를 가지고 있지만 다른 사람들과 함께 있어야 합니다.\n\nESFP는 다음과 같은 직업 유형에 탁월합니다.",
    "explain2": "간호사 / 인테리어 디자이너 / 사진작가 / 판매 담당자 / 이벤트 기획자",
    "result_imgname": "img/ESFP.jpeg"
  }
};

//테스트 시작함수
var testStart = function(){
  dataLayer.push({
    'event': 'start'
  });
  document.querySelector('#main').style.display = "none";
  document.querySelector('#test').style.display = "block";
  next();
}

document.querySelector('#start_btn').addEventListener('click', testStart);

//테스트 다시시작
var retry = function(){
  document.querySelector('#result').style.display = "none";
  document.querySelector('#test').style.display = "block";
  i = 1;
  EI.value=SN.value=TF.value=JP.value= 0;
  dataLayer.push({
    'event': 'retry'
  });
  next();
}

document.querySelector('#retry_btn').addEventListener('click', retry);

//타입 선택을 위한 함수
document.querySelector('#A').addEventListener('click',function(){
  var type = document.querySelector('#type').value;
  var preValue = document.querySelector('#'+type).value;
  document.querySelector('#'+type).value = preValue+1;
  dataLayer.push({
    'event': 'select_answer',
    'answer': 'A'
  });
  next();
})

document.querySelector('#B').addEventListener('click',function(){
  dataLayer.push({
    'event': 'select_answer',
    'answer': 'B'
  });
  next();
})


//문제 넘기기 + 결과 도출 함수
var next = function(){
  if(i==13){
    document.querySelector('#test').style.display = "none";
    document.querySelector('#result').style.display = "block";
    var mbti = '';
    if(document.querySelector('#EI').value < 2){
      mbti += 'I';
    }else{
      mbti += 'E';
    }
    if(document.querySelector('#SN').value < 2){
      mbti += 'N';
    }else{
      mbti += 'S';
    }
    if(document.querySelector('#TF').value < 2){
      mbti += 'F';
    }else{
      mbti += 'T';
    }
    if(document.querySelector('#JP').value < 2){
      mbti += 'P';
    }else{
      mbti += 'J';
    }
    console.log(mbti);
    document.querySelector('#mymbti').innerHTML = result[mbti]['mbti'];
    document.querySelector('#explain').innerHTML = result[mbti]['explain'];
    document.querySelector('#explain2').innerHTML = result[mbti]['explain2'];
    document.querySelector('#result_img').src= result[mbti]['result_imgname'];
    history.replaceState({result: mbti}, '', '?result='+mbti);
    dataLayer.push({
      'event': 'test_complete',
      'mbti': mbti,
      'result_name': result[mbti]['mbti']
    });
  }
  else{
    document.querySelector('#number').innerHTML = i+'/12';
    document.querySelector('#progress').style.width = (i/12)*100+'%';
    document.querySelector('#title').innerHTML = testNum[i]['title'];
    document.querySelector('#description').innerHTML = testNum[i]['description'];
    document.querySelector('#type').value = testNum[i]['type'];
    document.querySelector('#A').innerHTML = testNum[i]['A'];
    document.querySelector('#B').innerHTML = testNum[i]['B'];
    dataLayer.push({
      'event': 'view_question',
      'question_no': i
    });
    i++;
  }
}

  // 쿼리 파라미터 값이 있으면 결과 페이지로 바로 가기
  var shareParams = new URL(location.href).searchParams.get('result');
  if (Object.keys(result).includes(shareParams) === true){
      document.querySelector('#main').style.display = "none";
      document.querySelector('#result').style.display = "block";
      var mbti = shareParams;
      document.querySelector('#mymbti').innerHTML = result[mbti]['mbti'];
      document.querySelector('#explain').innerHTML = result[mbti]['explain'];
      document.querySelector('#explain2').innerHTML = result[mbti]['explain2'];
      document.querySelector('#result_img').src= result[mbti]['result_imgname'];
  }


  // 카카오톡 SDK 초기화하기
  Kakao.init('976f72e0732efa0f1bd1759b52724652');
  Kakao.isInitialized();

  // 카카오톡으로 공유하기 실행 함수
  var kakaoShare = function(){
    dataLayer.push({
      'event': 'kakao_share'
    });
    var title = document.querySelector('#main').textContent;
    var desc = document.querySelector('#explain').textContent;
    var imgUrl = document.querySelector('#result_img').src;
    var mbti = new URL(location.href).searchParams.get('result');

    Kakao.Link.sendDefault({
      objectType: 'feed',
      content: {
      title: title,
      description: desc,
      imageUrl:
        imgUrl,
      link: {
        mobileWebUrl: 'https://myjobmbti.netlify.app?result='+mbti,
    },
  },
  buttons: [
    {
      title: '결과 확인하기',
      link: {
        mobileWebUrl: 'https://myjobmbti.netlify.app?result='+mbti,
        webUrl: 'https://myjobmbti.netlify.app?result='+mbti
      },
    },
    {
      title: '나도 테스트하기',
      link: {
        mobileWebUrl: 'https://myjobmbti.netlify.app',
        webUrl: 'https://myjobmbti.netlify.app'
      },
    },
  ]
});
  }

  document.querySelector('#share_btn').addEventListener('click', kakaoShare);
